Company salespeople upload their sales figures daily. A Solutions Architect needs a durable storage solution for these documents that
also protects against users accidentally deleting important documents.

Which action will protect against unintended user actions?
