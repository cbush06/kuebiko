An application requires a highly available relational database with an initial storage capacity of 8 TB. The database will
grow by 8 GB every day. To support expected traffic, at least eight read replicas will be required to handle database reads.

Which option will meet these requirements?
