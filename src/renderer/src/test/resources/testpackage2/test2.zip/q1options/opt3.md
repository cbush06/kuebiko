Obtain the access key from a key server launched in a private subnet.
