Put the access key in an S3 bucket, and retrieve the access key on boot from the instance.
