Create an IAM role with permissions to access the table, and launch all instances with the new role.
