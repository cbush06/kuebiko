Pass the access key to the instances through instance user data.
