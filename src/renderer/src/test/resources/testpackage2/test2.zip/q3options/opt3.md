Store data in two S3 buckets in different AWS regions.
