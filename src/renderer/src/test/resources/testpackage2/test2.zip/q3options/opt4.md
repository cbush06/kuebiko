Store data on EC2 instance storage.
