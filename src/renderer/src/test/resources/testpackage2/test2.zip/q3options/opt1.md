Store data in an EBS volume and create snapshots once a week.
