Store data in an S3 bucket and enable versioning.
