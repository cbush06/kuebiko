A company is developing a highly available web application using stateless web servers. Which services are suitable for storing
session state data? **(Select TWO.)**
