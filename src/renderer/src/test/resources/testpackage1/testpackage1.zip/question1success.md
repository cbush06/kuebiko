Great job! Other definitions for **phishing** include:

-   The act of sending email that falsely claims to be from a legitimate organization. This is usually combined with a threat or request for information: for example, that an account will close, a balance is due, or information is missing from an account. The email will ask the recipient to supply confidential information, such as bank account details, PINs or passwords; these details are then used by the owners of the website to conduct fraud.
-   The act of circumventing security with an alias.
-   The practice of tricking Internet users (as through the use of deceptive email messages or websites) into revealing personal or confidential information which can then be used illicitly.
