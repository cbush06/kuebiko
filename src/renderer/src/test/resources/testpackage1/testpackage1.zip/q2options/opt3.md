Spam over Internet Telephony (SPIT)
