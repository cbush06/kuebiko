Uh oh! Note that **phishing** is the correct answer. Merriam-Webster Dictionary defines it as

> The practice of tricking Internet users (as through the use of deceptive email messages or websites) into revealing personal or confidential information which can then be used illicitly
