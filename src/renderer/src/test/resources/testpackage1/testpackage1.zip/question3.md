The practice of using a telephone system to manipulate user into disclosing confidential information is known as:

-   Whaling
-   Spear phishing
-   Vishing
-   Pharming
