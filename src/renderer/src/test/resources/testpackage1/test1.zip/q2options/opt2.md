E-mail communication
