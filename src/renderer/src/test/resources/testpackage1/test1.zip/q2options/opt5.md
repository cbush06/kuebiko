Spam over Internet Messaging (SPIM)
