Shoulder surfing
