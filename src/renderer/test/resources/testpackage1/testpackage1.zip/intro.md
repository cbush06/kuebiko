# Security+ 601

The test you are about to take is very difficult. It is divided into the following sections:

1. Network Fundamentals
2. Network Intrustion Prevention and Detection Systems
3. Software Security Fundamentals

You will have **120 minutes** to complete the exam.
