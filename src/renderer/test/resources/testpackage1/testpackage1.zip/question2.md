Which of the following answers refer to smishing? **(Select 2 answers)**

-   Social engineering technique
-   E-mail communication
-   Spam over Internet Telephony (SPIT)
-   Text messaging
-   Spam over Internet Messaging (SPIM)
