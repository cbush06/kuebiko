A social engineering technique whereby attackers under disguise of a legitimate request attempt to gain access to confidential information is commonly referred to as:

-   Phishing
-   Privilege escalation
-   Backdoor access
-   Shoulder surfing
