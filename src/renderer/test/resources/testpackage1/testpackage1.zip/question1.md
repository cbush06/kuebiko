What is the solution to `2 + 2`?
